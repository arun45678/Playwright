function getDCJson() {
    return {
        qa: {         
          system: 'systemqa2.asite.com',
          portal: 'portalqa2.asite.com',       
          optionName: 'Asite Cloud',
          options: ['qa','sb']
        },
        newqa: {         
          system: 'systemqa.asite.com',
          portal: 'portalqa.asite.com',          
          optionName: 'Asite Cloud',
          options: ['newqa','sb']
        },        
        qaak: {
          system: 'systemqa2ak.asite.com',
          portal: 'portalqa2.asite.com',    
          optionName: 'Asite Cloud',
          options: ['qa','sb']
        },
        newqaak: {
          system: 'systemqaak.asite.com',
          portal: 'portalqa.asite.com',          
          optionName: 'Asite Cloud',
          options: ['newqaak','sb']
        }, 
        stg: {
          system: 'systemstg.asite.com',
          portal: 'portalstg.asite.com',
          optionName: 'Asite Cloud',
          options: ['stg','sb']
        },
        sb: {
          system: 'systemsb.asite.com',
          portal: 'portalsb.asite.com',
          optionName: 'Asite Sandbox Cloud',
          options: []
        },
        usgov: {
          system: 'systemusgov.asite.com',
          portal: 'portalusgov.asite.com',
          optionName: 'Asite US Gov. Cloud',
          options: []
        },
        uae: {
          system: 'systemuae.asite.com',
          portal: 'portaluae.asite.com',
          optionName: 'Asite UAE Cloud',
          options: []
        },
        ksa: {
          system: 'systemksa.asite.com',
          portal: 'portalksa.asite.com',
          optionName: 'Asite KSA Cloud',
          options: []
        },
        live: {
          system: 'system.asite.com',
          portal: 'portal.asite.com',
          optionName: 'Asite Cloud',
          options: ['live','usgov','uae','ksa','canada', 'hongkong']
        },
        canada: {
          system: 'systemh.asite.com',
          portal: 'portalh.asite.com',
          optionName: 'Asite Canada Cloud',
          options: []
        },
        hongkong: {
          system: 'systemhk.asite.com',
          portal: 'portalhk.asite.com',
          optionName: 'Asite Hong Kong Cloud',
          options: []
        },
        dev:{
          system: 'systemdev.asite.com',
          portal: 'portaldev.asite.com',
          optionName: 'Asite Cloud',
          options: []
        }
    };
}