$(document).on("scroll", onScrollHeaderActive);

function onScrollHeaderActive(event){
	var scrollPosition = $(document).scrollTop();
    $($('.tab_nav').get().reverse()).each(function () {
      var currentLink = $(this);
      $(currentLink).removeClass("active");
      var refElement = currentLink.attr("class").split(' ')[1];
      var isVisible = isElementInViewport($("#"+refElement).parent(), refElement)
      if(isVisible){
          $(currentLink).addClass("active");
            // return false;           
      }
    });
}

function isElementInViewport (el,refElement) {
    if (typeof jQuery === "function" && el instanceof jQuery) { 
        el = el[0];
    }
    if(!el){
        return false;
    }
    var rect = el.getBoundingClientRect();
    return (
        rect.top <= 75 &&
        rect.bottom > 75 );
}


function moveToLocation(element_id) {
    var $element = $('#' + element_id);
    if(!$element.length) {
        return;
    }
	var top_pos = $element.offset().top - 72;
	$(".active").removeClass("active");
	$("." + element_id).addClass("active");
    $('html,body').animate({
     	scrollTop: top_pos
    });
}

// $(window).load(function(){
//     if(window.location.hash){
//         setTimeout(function(){
//             moveToLocation(window.location.hash.replace("#", ""));    
//         });
//     } 
// });

